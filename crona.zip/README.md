this program for get updateable crona data from global website and response it for users.
you can see all country info and total confirmed and deaths and recovered into /api/getdata .
and see seperate information using coutry id by /api/getdata/{id} -> exp -> /api/getdata/10 .
data update with cron job every minute (this time chaneable).

Thank You.
